import{c as t}from"./index-Bkfdoov4.js";/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=t("ClipboardList",[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}],["path",{d:"M12 11h4",key:"1jrz19"}],["path",{d:"M12 16h4",key:"n85exb"}],["path",{d:"M8 11h.01",key:"1dfujw"}],["path",{d:"M8 16h.01",key:"18s6g9"}]]);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=t("Headphones",[["path",{d:"M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 18 0v7a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3",key:"1xhozi"}]]),c={trial:"Período de teste",active:"Ativa",past_due:"Pagamento em atraso",expired:"Acesso vencido",suspended:"Suspensa",cancelled:"Cancelada",unavailable:"Indisponível"},o={pending:"Pendente",paid:"Paga",cancelled:"Cancelada",cancellation_requested:"Cancelamento em processamento",refunded:"Estornada",charged_back:"Contestada"};function r(a,e){return e==="configuracoes"||e==="suporte"?!0:(a==null?void 0:a.can_access)===!0&&a.features.includes(e)}function h(a){return a?new Date(a).toLocaleDateString("sv-SE",{timeZone:"America/Sao_Paulo"}):""}export{s as C,d as H,c as a,o as b,r as c,h as s};
